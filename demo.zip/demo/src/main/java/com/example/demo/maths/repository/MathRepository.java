package com.example.demo.maths.repository;

public interface MathRepository {
    
    int getNumber();

}
