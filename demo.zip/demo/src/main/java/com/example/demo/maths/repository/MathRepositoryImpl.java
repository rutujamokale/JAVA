package com.example.demo.maths.repository;

public class MathRepositoryImpl implements MathRepository {
    
    @Override

    public int getNumber(){
        return 42;
    }

}
