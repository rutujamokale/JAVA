package com.example.demo.maths.service;

public interface CalculatorService {
    
    int doubleNumber();
}
